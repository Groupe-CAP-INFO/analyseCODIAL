GLPI_URL = "https://glpi.groupecapinfo.fr/apirest.php"
GLPI_APP_TOKEN = "N7SKdbBnLYIol8bjj9us8Shst3BvWJV5BINhhSpe"
GLPI_LOGIN = "jf.godeliez@groupecapinfo.fr"
GLPI_PASSWORD = "GqRnu2uh1DN7Mntb@GdnE%6$x"
