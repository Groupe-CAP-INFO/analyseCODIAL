---
name: project-glpi-integration
description: "Plan d'intégration CODIAL → GLPI v10 — architecture, mapping données, modules à développer, état d'avancement"
metadata:
  node_type: memory
  type: project
  originSessionId: c5016358-b5c1-4c2a-9d9a-1a6da84e552a
---

Objectif : synchroniser les données CODIAL (HFSQL) vers GLPI v10 pour donner aux clients un accès portail (Hotline, Contrats, Factures).

## Statut actuel (2026-06-19)
- ✅ Connexion GLPI REST API vérifiée et opérationnelle
- ✅ glpi_client.py créé (wrapper REST API complet)
- ✅ Structure des entités GLPI explorée (hiérarchie complète connue)
- ✅ Champs CLIENT CODIAL identifiés pour le mapping
- ✅ sync/sync_entities.py — exécuté (2 955 créés, 25 mis à jour, 10 erreurs)
- ✅ sync/map_existing_entities.py — appliqué (26 mappés, 37 protégés, 0 erreurs)
- ✅ sync/manage_parents.py — gestion parent_overrides
- ✅ entity_map_review.csv — relu et appliqué
- ⏳ 10 doublons à régler manuellement (lundi 2026-06-23)
- 🔲 sync/sync_users.py
- 🔲 sync/sync_contracts.py
- 🔲 sync/sync_tickets.py
- 🔲 sync/sync_invoices.py
- 🔲 sync_runner.py — orchestrateur

## 10 erreurs en attente (lundi)
Cause : entités déjà dans GLPI à la racine sans registration_number → doublon au CREATE.
Fix prévu : script qui cherche ces noms dans GLPI, affiche les IDs candidats, demande confirmation, puis insère dans mapping.db.
| Code CODIAL | Nom GLPI |
|---|---|
| CAGFPME | AGEFOS PME |
| CBRIPH | PH LAPORTE |
| CCHAMBR | CHAMBRES OLIVIER |
| CJDELAG | DELAGE JACQUES |
| CMONTER | MONTERO CARINE |
| CROUX01 | ROUX |
| CTAUZIN | TAUZIN |
| GRO04 | GROUPE UNIVERP |
| MIN01 | MINDURRY PROMOTION |
| SAS01 | TPI |

## Hiérarchie GLPI connue (2026-06-18)
```
Entité racine (0)
├── Groupe BELLEC (1)          [CONTENEUR — pas dans CODIAL]
│   ├── AGS NISSAN (16)        [CONTENEUR suggéré]
│   │   ├── LA TESTE (17)
│   │   └── ARES (18)
│   ├── RENAULT COTE D'ARGENT (19) [AUTO → CCOTEAR]
│   │   ├── LA TESTE (20), BIGANOS (21), BISCARROSSE (22), Plateforme PR (25)
│   ├── COTE D'ARGENT DEPANNAGE (23)
│   ├── MJ 33 (24)             [AUTO → CMJ3300]
│   └── Brasserie MIRA (26)    [AUTO → CBRAMIR]
│       ├── Avenue Vulcain (27)
│       ├── Logistique (28)    [AUTO → C2LLOGI]
│       └── Commerciaux (63)   [INTERNE]
├── Groupe CAP INFO (2)        [INTERNE]
│   ├── Siège - Artigues (3) → Serveurs (6), Postes (31)
│   ├── Datacenter OVH (5)
│   └── PersoJFG (58)
├── GARAGE LAMERAIN (29)       [AUTO → CRENAULTST]
│   ├── SAINT-JEAN-DE-LUZ (14)
│   └── HENDAYE (15)
├── ALAIN MARTIN (32)          [CONTENEUR suggéré]
│   ├── DUPLACEAU (33)         [AUTO → CDUPLAC]
│   └── CANEJAN (34)
├── ETS J BOURDEN (35)         [CONTENEUR suggéré]
│   ├── RION-DES-LANDES (36), MORCENX (37), ST ENGRACE (39)
├── TALDI (40)                 [AUTO → SAR01]
│   ├── TALDI MERIGNAC (41), G2E (42), CAPVINS (43)→LE CANON (45), CAPVINS MERIGNAC (44)
│   └── ETS SERRANO (46)
├── TRISCOS AUTOMOBILES (47)   [AUTO → CTRISCO]
│   ├── BISCARROSSE (49), AD CARROSSERIE (50), RENAULT (51)
├── KORERO (54)                [AUTO → CKORERO]
│   ├── MONT DE MARSAN (55), MERIGNAC (56)
├── Groupe Univerp (64)        [AUTO → GRO04 — doublon avec 65]
│   ├── Univerp (65)           [AUTO → GRO04 — doublon avec 64]
│   │   └── Gétigné (70)
│   ├── Groupe Différence (66), Adibat (67), SBI87 (68), Aclea (69)
└── UFA (71)                   [AUTO → CUNIONF]
    └── UFA - Floirac (72)
```

## Architecture mapping.db (3 tables)
- `entity_map(codial_code, glpi_id, codial_nom, synced_at)` — mapping CODIAL → GLPI
- `protected_entities(glpi_id, glpi_nom, created_at)` — entités jamais touchées par le sync
- `parent_overrides(codial_code, glpi_parent_id, note, created_at)` — futurs clients sous groupe spécifique

## Comportement sync_entities.py
- UPDATE : ne change jamais entities_id (position dans l'arbre préservée)
- UPDATE : skip si glpi_id dans protected_entities
- CREATE : utilise parent_overrides si défini, sinon entité racine (0)

## Corrections techniques apportées (2026-06-17/18)
- hfsql_bridge.py : timeout 30s → 120s, encodage UTF-8 forcé
- SQL sur une seule ligne (HFSQL refuse les \n via ODBC)
- map_existing_entities.py : entité racine (0) exclue du CSV, INTERNAL_IDS forcés valide=0

## Accès GLPI (dans config.py — hors git)
- URL : https://glpi.groupecapinfo.fr/apirest.php
- App-Token : N7SKdbBnLYIol8bjj9us8Shst3BvWJV5BINhhSpe
- Login : jf.godeliez@groupecapinfo.fr

## Architecture retenue
```
CODIAL HFSQL (réseau local)
    ↓  hfsql_bridge.py
Python Sync Engine (poste local ou serveur)
    ↓  HTTPS — GLPI REST API
GLPI v10 (hébergé cloud : glpi.groupecapinfo.fr)
```
Mode sync : planifiée (nuit), sens unique CODIAL → GLPI.

## Mapping données CODIAL → GLPI

### CLIENT → Entity GLPI
| CODIAL | GLPI | Notes |
|---|---|---|
| CLIENT.CODE | registration_number | clé de synchro |
| CLIENT.NOM | name | |
| CLIENT.ADRESSE1 | address | |
| CLIENT.VILLE | town | |
| CLIENT.TEL | phonenumber | |
| CLIENT.EMAIL | email | |
| CLIENT.SITE_WEB | website | |
| — | entities_id | parent_overrides ou 0 (racine) |

Filtre : `FICHE_SUPPRIME=0 AND NOM <> ''` — 2 989 clients actifs.
CODIAL n'a pas de champ de regroupement inter-clients (CODE_CENTRALE = auto-référence).

### FA4_TIERS_CONTACT → User GLPI (🔲)
### FA4_CONTRAT_CLIENT → Contract GLPI (🔲)
### FA4_CAPPEL_HOTLINE → Ticket GLPI (🔲)
### FACTURE → Document GLPI (🔲)

## Fichiers projet
```
analyseCODIAL/
├── hfsql_bridge.py              ✅
├── glpi_client.py               ✅
├── config.py                    ✅ (gitignored)
├── entity_map_review.csv        ⏳ EN ATTENTE relecture
├── sync/
│   ├── map_existing_entities.py ✅ (protege, CONTENEUR, protected_entities)
│   ├── manage_parents.py        ✅ nouveau — gestion parent_overrides
│   ├── sync_entities.py         ✅ (protected_entities + parent_overrides)
│   ├── sync_users.py            🔲
│   ├── sync_contracts.py        🔲
│   ├── sync_tickets.py          🔲
│   └── sync_invoices.py         🔲
└── sync_runner.py               🔲
```

**Why:** Portail client GLPI alimenté depuis CODIAL — hotline/contrats/factures selon profil.
**How to apply:** SQL sur une seule ligne. Clé synchro = CLIENT.CODE → registration_number. Ne jamais changer entities_id sur update. Vérifier protected_entities avant toute écriture.
