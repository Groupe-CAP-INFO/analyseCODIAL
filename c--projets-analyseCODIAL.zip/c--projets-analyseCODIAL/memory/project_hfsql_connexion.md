---
name: project-hfsql-connexion
description: "Configuration et connexion au serveur HFSQL CODIAL — stack technique, problèmes résolus, architecture du bridge"
metadata: 
  node_type: memory
  type: project
  originSessionId: c5016358-b5c1-4c2a-9d9a-1a6da84e552a
---

Serveur HFSQL v29 (WinDev 29.0.429.10) accessible via ODBC sur 192.168.0.4:4900, base CAPINFO, user admin.

**Problèmes résolus :**
- Driver ODBC "HFSQL" enregistré en v21 → incompatible avec serveur v29. Fix : DSN User `TEST-HFSQL-CODIAL` dans HKCU mis à jour pour pointer vers `C:\Program Files\Common Files\PC SOFT\2024\ODBC\Win64x86\wd290hfo64.dll` (v29, sans droits admin)
- pyodbc incompatible avec Python 3.14 RC (SystemError) → contourné via bridge PowerShell + System.Data.Odbc

**Architecture retenue :**
- `hfsql_bridge.py` : bridge Python→PowerShell→ODBC (fichier .ps1 temp + subprocess). Fonctions : `list_tables()`, `query(sql)`, `test_connection()`
- `scan_hfsql.py` : script de scan utilisant le bridge
- Python 3.14 (C:\Python314) + pyodbc 5.3.0 (incompatible 3.14, contourné)
- Python 3.13 disponible (py -3.13) mais pyodbc non installé dessus

**Base CAPINFO : 923 tables** dont ARTICLE, CLIENT, BL, CONTRAT, etc.

**Why:** Serveur CODIAL (ERP) en réseau local. Objectif : analyser les données de gestion.
**How to apply:** Toujours utiliser hfsql_bridge pour les accès données. Ne pas tenter pyodbc sur Python 3.14. Si Python 3.13 + pyodbc disponible, c'est une alternative directe.
