# Mémoire projet analyseCODIAL

- [Connexion HFSQL — stack, problèmes résolus, bridge](project_hfsql_connexion.md) — Serveur v29, bridge Python→PowerShell→ODBC, DSN fixé, 923 tables
- [Intégration GLPI v10 — plan complet](project_glpi_integration.md) — En attente accès GLPI (URL, App-Token, login admin) pour démarrer le code
